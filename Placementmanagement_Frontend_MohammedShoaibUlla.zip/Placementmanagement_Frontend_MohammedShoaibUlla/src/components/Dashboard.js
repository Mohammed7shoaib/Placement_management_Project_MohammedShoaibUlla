import React, { useEffect, useState } from "react";
import API_URL from "../api";

const quickActions = [
  {
    key: "students",
    icon: "🎓",
    title: "Add Student",
    description: "Create a new student record."
  },
  {
    key: "colleges",
    icon: "🏫",
    title: "Add College",
    description: "Create a new college record."
  },
  {
    key: "placements",
    icon: "💼",
    title: "Add Placement",
    description: "Create a new placement record."
  },
  {
    key: "users",
    icon: "👤",
    title: "Add User",
    description: "Create a new system user."
  },
  {
    key: "certificates",
    icon: "📜",
    title: "Add Certificate",
    description: "Create a new certificate record."
  },
  {
    key: "admins",
    icon: "⚙️",
    title: "Add Admin",
    description: "Create a new administrator record."
  }
];
function Dashboard({ onNavigate }) {

  const [counts, setCounts] = useState({
    students: 0,
    colleges: 0,
    placements: 0,
    certificates: 0,
    users: 0,
    admins: 0
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");


  useEffect(() => {

    const loadDashboard = async () => {

      try {

        setLoading(true);
        setError("");

        console.log("API URL:", API_URL);

        const endpoints = [
          "getstudent",
          "getcollege",
          "getplacement",
          "getcertificate",
          "getuser",
          "getadmin"
        ];

        const results = {};

        for (const endpoint of endpoints) {

          console.log(
            `Testing: ${API_URL}/${endpoint}`
          );

          const response = await fetch(
            `${API_URL}/${endpoint}`
          );

          console.log(
            `${endpoint} status:`,
            response.status,
            response.ok
          );

          if (!response.ok) {

            throw new Error(
              `${endpoint} failed with status ${response.status}`
            );
          }

          const data = await response.json();

          console.log(
            `${endpoint} data:`,
            data
          );

          results[endpoint] = data;
        }


        setCounts({
          students: results.getstudent.length,
          colleges: results.getcollege.length,
          placements: results.getplacement.length,
          certificates: results.getcertificate.length,
          users: results.getuser.length,
          admins: results.getadmin.length
        });


      } catch (err) {

        console.error(
          "DASHBOARD ERROR:",
          err
        );

        setError(
          `Dashboard error: ${err.message}`
        );

      } finally {

        setLoading(false);

      }
    };


    loadDashboard();

  }, []);


  return (

     <div>

      <div className="page-header">

        <h2>
          Dashboard
        </h2>

        <p>
          Overview of your placement management system.
        </p>

      </div>


      {error && (

        <div className="error-box">
          {error}
        </div>

      )}


      <div className="dashboard-grid">

        <div className="card stat-card">
          <div className="icon">🎓</div>
          <h3>Students</h3>
          <div className="number">
            {loading ? "..." : counts.students}
          </div>
        </div>


        <div className="card stat-card">
          <div className="icon">🏫</div>
          <h3>Colleges</h3>
          <div className="number">
            {loading ? "..." : counts.colleges}
          </div>
        </div>


        <div className="card stat-card">
          <div className="icon">💼</div>
          <h3>Placements</h3>
          <div className="number">
            {loading ? "..." : counts.placements}
          </div>
        </div>


        <div className="card stat-card">
          <div className="icon">📜</div>
          <h3>Certificates</h3>
          <div className="number">
            {loading ? "..." : counts.certificates}
          </div>
        </div>


        <div className="card stat-card">
          <div className="icon">👤</div>
          <h3>Users</h3>
          <div className="number">
            {loading ? "..." : counts.users}
          </div>
        </div>


        <div className="card stat-card">
          <div className="icon">⚙️</div>
          <h3>Admins</h3>
          <div className="number">
            {loading ? "..." : counts.admins}
          </div>
        </div>

      </div>


      <div className="page-header quick-actions-header">

        <h2>
          Quick Add Data
        </h2>

        <p>
          Select a main functionality to open its data-entry form.
        </p>

      </div>


      <div className="quick-actions-grid">

        {quickActions.map((action) => (

          <div
            className="card quick-action-card"
            key={action.key}
          >

            <div className="quick-action-icon">
              {action.icon}
            </div>

            <div className="quick-action-content">

              <h3>
                {action.title}
              </h3>

              <p>
                {action.description}
              </p>

              <button
                className="btn btn-primary quick-action-button"
                type="button"
                onClick={() =>
                  onNavigate(action.key)
                }
              >
                {action.title}
              </button>

            </div>

          </div>

        ))}

      </div>


      <div className="card welcome">

        <h2>
          Welcome
        </h2>

        <p>
          Use Quick Add Data above or the menu to manage students,
          colleges, placements, certificates, users and administrators.
        </p>

      </div>

    </div>

  );
}

export default Dashboard;