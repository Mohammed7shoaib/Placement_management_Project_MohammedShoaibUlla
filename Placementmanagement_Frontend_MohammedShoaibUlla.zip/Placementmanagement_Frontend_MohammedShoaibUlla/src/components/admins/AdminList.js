import React, { useEffect, useState } from "react";
import API_URL from "../../api";

function AdminList() {
  const [admins, setAdmins] = useState([]);
  const [form, setForm] = useState({ name: "", password: "" });
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState("");

  const fetchAdmins = async () => {
    try {
      const response = await fetch(`${API_URL}/getadmin`);
      if (!response.ok) throw new Error();
      setAdmins(await response.json());
    } catch (err) {
      console.error(err);
      setError("Could not load admins.");
    }
  };

  useEffect(() => {
    fetchAdmins();
  }, []);

  const resetForm = () => {
    setForm({ name: "", password: "" });
    setEditingId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const url = editingId
        ? `${API_URL}/updateadmin/${editingId}`
        : `${API_URL}/saveadmin`;

      const response = await fetch(url, {
        method: editingId ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });

      if (!response.ok) throw new Error();

      resetForm();
      fetchAdmins();
    } catch (err) {
      console.error(err);
      setError("Could not save admin.");
    }
  };

  const deleteAdmin = async (id) => {
    if (!window.confirm("Are you sure you want to delete this admin?")) return;

    try {
      const response = await fetch(`${API_URL}/deleteadmin/${id}`, {
        method: "DELETE"
      });

      if (!response.ok) throw new Error();
      fetchAdmins();
    } catch (err) {
      console.error(err);
      setError("Could not delete admin.");
    }
  };

  return (
    <div>
      <div className="page-header">
        <h2>Admin Management</h2>
        <p>Manage administrator records.</p>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="card form-card">
        <form onSubmit={handleSubmit}>
          <div className="form-grid">
            <div className="field">
              <label>Admin Name</label>
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
              />
            </div>

            <div className="field">
              <label>Password</label>
              <input
                type="password"
                value={form.password}
                onChange={(e) =>
                  setForm({ ...form, password: e.target.value })
                }
                required={!editingId}
              />
            </div>
          </div>

          <div className="form-actions">
            <button className="btn btn-primary" type="submit">
              {editingId ? "Update Admin" : "Add Admin"}
            </button>

            {editingId && (
              <button className="btn btn-secondary" type="button" onClick={resetForm}>
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>

      <div className="card table-card">
        {admins.length === 0 ? (
          <div className="empty">No admins found.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Password</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {admins.map((admin) => (
                <tr key={admin.id}>
                  <td>{admin.id}</td>
                  <td>{admin.name}</td>
                  <td>••••••••</td>
                  <td className="action-cell">
                    <button
                      className="btn btn-edit"
                      onClick={() => {
                        setEditingId(admin.id);
                        setForm({
                          name: admin.name || "",
                          password: ""
                        });
                      }}
                    >
                      Edit
                    </button>

                    <button
                      className="btn btn-delete"
                      onClick={() => deleteAdmin(admin.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default AdminList;