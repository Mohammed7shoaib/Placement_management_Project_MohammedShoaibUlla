import React from "react";

const menuItems = [
  { key: "dashboard", label: "📊 Dashboard" },
  { key: "students", label: "🎓 Students" },
  { key: "colleges", label: "🏫 Colleges" },
  { key: "placements", label: "💼 Placements" },
  { key: "certificates", label: "📜 Certificates" },
  { key: "users", label: "👤 Users" },
  { key: "admins", label: "⚙️ Admins" }
];

function Sidebar({ activePage, setActivePage, sidebarOpen }) {
  return (
    <aside className={`sidebar ${sidebarOpen ? "" : "closed"}`}>
      <div className="logo">
        <h2>PMS</h2>
        <span>Placement Management System</span>
      </div>

      <nav className="nav-menu">
        {menuItems.map((item) => (
          <button
            key={item.key}
            className={`nav-button ${activePage === item.key ? "active" : ""}`}
            onClick={() => setActivePage(item.key)}
          >
            {item.label}
          </button>
        ))}
      </nav>
    </aside>
  );
}

export default Sidebar;