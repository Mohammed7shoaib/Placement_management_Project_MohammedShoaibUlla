import React, { useEffect, useState } from "react";
import API_URL from "../../api";

function UserList() {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({
    name: "",
    email: "",
    designation: ""
  });
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState("");

  const fetchUsers = async () => {
    try {
      const response = await fetch(`${API_URL}/getuser`);
      if (!response.ok) throw new Error();
      setUsers(await response.json());
    } catch (err) {
      console.error(err);
      setError("Could not load users.");
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const resetForm = () => {
    setForm({ name: "", email: "", designation: "" });
    setEditingId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const url = editingId
        ? `${API_URL}/updateuser/${editingId}`
        : `${API_URL}/saveuser`;

      const response = await fetch(url, {
        method: editingId ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });

      if (!response.ok) throw new Error();

      resetForm();
      fetchUsers();
    } catch (err) {
      console.error(err);
      setError("Could not save user.");
    }
  };

  const deleteUser = async (id) => {
    if (!window.confirm("Are you sure you want to delete this user?")) return;

    try {
      const response = await fetch(`${API_URL}/deleteuser/${id}`, {
        method: "DELETE"
      });

      if (!response.ok) throw new Error();
      fetchUsers();
    } catch (err) {
      console.error(err);
      setError("Could not delete user.");
    }
  };

  return (
    <div>
      <div className="page-header">
        <h2>User Management</h2>
        <p>Manage system users.</p>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="card form-card">
        <form onSubmit={handleSubmit}>
          <div className="form-grid">
            <div className="field">
              <label>Name</label>
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
              />
            </div>

            <div className="field">
              <label>Email</label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                required
              />
            </div>

            <div className="field">
              <label>Designation</label>
              <input
                value={form.designation}
                onChange={(e) =>
                  setForm({ ...form, designation: e.target.value })
                }
                required
              />
            </div>
          </div>

          <div className="form-actions">
            <button className="btn btn-primary" type="submit">
              {editingId ? "Update User" : "Add User"}
            </button>

            {editingId && (
              <button className="btn btn-secondary" type="button" onClick={resetForm}>
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>

      <div className="card table-card">
        {users.length === 0 ? (
          <div className="empty">No users found.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Designation</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id}>
                  <td>{user.id}</td>
                  <td>{user.name}</td>
                  <td>{user.email}</td>
                  <td>{user.designation}</td>
                  <td className="action-cell">
                    <button
                      className="btn btn-edit"
                      onClick={() => {
                        setEditingId(user.id);
                        setForm({
                          name: user.name || "",
                          email: user.email || "",
                          designation: user.designation || ""
                        });
                      }}
                    >
                      Edit
                    </button>

                    <button
                      className="btn btn-delete"
                      onClick={() => deleteUser(user.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default UserList;