import React, { useEffect, useState } from "react";
import API_URL from "../../api";

function CollegeList() {
  const [colleges, setColleges] = useState([]);
  const [form, setForm] = useState({ collegeName: "", location: "" });
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState("");

  const fetchColleges = async () => {
    try {
      const response = await fetch(`${API_URL}/getcollege`);
      if (!response.ok) throw new Error();
      setColleges(await response.json());
    } catch (err) {
      console.error(err);
      setError("Could not load colleges.");
    }
  };

  useEffect(() => {
    fetchColleges();
  }, []);

  const resetForm = () => {
    setForm({ collegeName: "", location: "" });
    setEditingId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const url = editingId
        ? `${API_URL}/updatecollege/${editingId}`
        : `${API_URL}/savecollege`;

      const response = await fetch(url, {
        method: editingId ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });

      if (!response.ok) throw new Error();

      resetForm();
      fetchColleges();
    } catch (err) {
      console.error(err);
      setError("Could not save college.");
    }
  };

  const deleteCollege = async (id) => {
    if (!window.confirm("Are you sure you want to delete this college?")) return;

    try {
      const response = await fetch(`${API_URL}/deletecollege/${id}`, {
        method: "DELETE"
      });

      if (!response.ok) throw new Error();
      fetchColleges();
    } catch (err) {
      console.error(err);
      setError("Could not delete college.");
    }
  };

  return (
    <div>
      <div className="page-header">
        <h2>College Management</h2>
        <p>Manage college information.</p>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="card form-card">
        <form onSubmit={handleSubmit}>
          <div className="form-grid">
            <div className="field">
              <label>College Name</label>
              <input
                value={form.collegeName}
                onChange={(e) =>
                  setForm({ ...form, collegeName: e.target.value })
                }
                required
              />
            </div>

            <div className="field">
              <label>Location</label>
              <input
                value={form.location}
                onChange={(e) =>
                  setForm({ ...form, location: e.target.value })
                }
                required
              />
            </div>
          </div>

          <div className="form-actions">
            <button className="btn btn-primary" type="submit">
              {editingId ? "Update College" : "Add College"}
            </button>

            {editingId && (
              <button className="btn btn-secondary" type="button" onClick={resetForm}>
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>

      <div className="card table-card">
        {colleges.length === 0 ? (
          <div className="empty">No colleges found.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>College Name</th>
                <th>Location</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {colleges.map((college) => (
                <tr key={college.id}>
                  <td>{college.id}</td>
                  <td>{college.collegeName}</td>
                  <td>{college.location}</td>
                  <td className="action-cell">
                    <button
                      className="btn btn-edit"
                      onClick={() => {
                        setEditingId(college.id);
                        setForm({
                          collegeName: college.collegeName || "",
                          location: college.location || ""
                        });
                      }}
                    >
                      Edit
                    </button>

                    <button
                      className="btn btn-delete"
                      onClick={() => deleteCollege(college.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default CollegeList;