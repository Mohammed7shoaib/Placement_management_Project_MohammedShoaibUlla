import React, { useEffect, useState } from "react";
import API_URL from "../../api";

function CertificateList() {
  const [certificates, setCertificates] = useState([]);
  const [form, setForm] = useState({ year: "", college: "" });
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState("");

  const fetchCertificates = async () => {
    try {
      const response = await fetch(`${API_URL}/getcertificate`);
      if (!response.ok) throw new Error();
      setCertificates(await response.json());
    } catch (err) {
      console.error(err);
      setError("Could not load certificates.");
    }
  };

  useEffect(() => {
    fetchCertificates();
  }, []);

  const resetForm = () => {
    setForm({ year: "", college: "" });
    setEditingId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const url = editingId
        ? `${API_URL}/updatecertificate/${editingId}`
        : `${API_URL}/savecertificate`;

      const response = await fetch(url, {
        method: editingId ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });

      if (!response.ok) throw new Error();

      resetForm();
      fetchCertificates();
    } catch (err) {
      console.error(err);
      setError("Could not save certificate.");
    }
  };

  const deleteCertificate = async (id) => {
    if (!window.confirm("Are you sure you want to delete this certificate?")) return;

    try {
      const response = await fetch(`${API_URL}/deletecertificate/${id}`, {
        method: "DELETE"
      });

      if (!response.ok) throw new Error();
      fetchCertificates();
    } catch (err) {
      console.error(err);
      setError("Could not delete certificate.");
    }
  };

  return (
    <div>
      <div className="page-header">
        <h2>Certificate Management</h2>
        <p>Manage certificate records.</p>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="card form-card">
        <form onSubmit={handleSubmit}>
          <div className="form-grid">
            <div className="field">
              <label>Year</label>
              <input
                type="number"
                value={form.year}
                onChange={(e) => setForm({ ...form, year: e.target.value })}
                required
              />
            </div>

            <div className="field">
              <label>College</label>
              <input
                value={form.college}
                onChange={(e) => setForm({ ...form, college: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="form-actions">
            <button className="btn btn-primary" type="submit">
              {editingId ? "Update Certificate" : "Add Certificate"}
            </button>

            {editingId && (
              <button className="btn btn-secondary" type="button" onClick={resetForm}>
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>

      <div className="card table-card">
        {certificates.length === 0 ? (
          <div className="empty">No certificates found.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Year</th>
                <th>College</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {certificates.map((certificate) => (
                <tr key={certificate.id}>
                  <td>{certificate.id}</td>
                  <td>{certificate.year}</td>
                  <td>{certificate.college}</td>
                  <td className="action-cell">
                    <button
                      className="btn btn-edit"
                      onClick={() => {
                        setEditingId(certificate.id);
                        setForm({
                          year: certificate.year || "",
                          college: certificate.college || ""
                        });
                      }}
                    >
                      Edit
                    </button>

                    <button
                      className="btn btn-delete"
                      onClick={() => deleteCertificate(certificate.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default CertificateList;