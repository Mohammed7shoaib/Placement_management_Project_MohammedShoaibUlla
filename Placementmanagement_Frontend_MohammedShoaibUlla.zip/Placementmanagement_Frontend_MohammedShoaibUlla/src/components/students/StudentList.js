import React, { useEffect, useState } from "react";
import API_URL from "../../api";
import StudentForm from "./StudentForm";

function StudentList() {

    const [students, setStudents] = useState([]);

    const [editingStudent, setEditingStudent] =
        useState(null);

    const [loading, setLoading] =
        useState(false);

    const [error, setError] =
        useState("");


    const fetchStudents = async () => {

        try {

            setLoading(true);
            setError("");

            const response = await fetch(
                `${API_URL}/getstudent`
            );

            if (!response.ok) {
                throw new Error(
                    "Failed to fetch students."
                );
            }

            const data =
                await response.json();

            setStudents(data);

        } catch (err) {

            console.error(err);

            setError(
                "Could not load students. " +
                "Check whether the backend is running."
            );

        } finally {

            setLoading(false);

        }
    };


    useEffect(() => {

        fetchStudents();

    }, []);


    const editStudent = (student) => {

        setEditingStudent(student);

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    };


    const deleteStudent = async (id) => {

        if (
            !window.confirm(
                "Are you sure you want to delete this student?"
            )
        ) {
            return;
        }


        try {

            setError("");

            const response = await fetch(
                `${API_URL}/deletestudent/${id}`,
                {
                    method: "DELETE"
                }
            );


            if (!response.ok) {

                throw new Error(
                    "Delete failed."
                );
            }


            await fetchStudents();


        } catch (err) {

            console.error(err);

            setError(
                "Could not delete student."
            );

        }
    };


    return (

        <div>

            {/* PAGE HEADER */}

            <div className="page-header">

                <h2>
                    Student Management
                </h2>

                <p>
                    Add, view, update and delete students.
                </p>

            </div>


            {/* ERROR MESSAGE */}

            {error && (

                <div className="error-box">
                    {error}
                </div>

            )}


            {/* ADD / EDIT FORM */}

            <StudentForm
                fetchStudents={fetchStudents}
                editingStudent={editingStudent}
                setEditingStudent={setEditingStudent}
            />


            {/* STUDENT TABLE */}

            <div className="card table-card">

                {loading ? (

                    <div className="empty">
                        Loading students...
                    </div>

                ) : students.length === 0 ? (

                    <div className="empty">
                        No students found.
                    </div>

                ) : (

                    <table className="data-table">

                        <thead>

                            <tr>

                                <th>ID</th>

                                <th>Name</th>

                                <th>Phone</th>

                                <th>College</th>

                                <th>Actions</th>

                            </tr>

                        </thead>


                        <tbody>

                            {students.map(
                                (student) => (

                                    <tr
                                        key={student.sid}
                                    >

                                        <td>
                                            {student.sid}
                                        </td>

                                        <td>
                                            {student.name}
                                        </td>

                                        <td>
                                            {student.phoneno}
                                        </td>

                                        <td>
                                            {student.collegeName}
                                        </td>

                                        <td className="action-cell">

                                            <button
                                                className="btn btn-edit"
                                                onClick={() =>
                                                    editStudent(
                                                        student
                                                    )
                                                }
                                            >
                                                Edit
                                            </button>


                                            <button
                                                className="btn btn-delete"
                                                onClick={() =>
                                                    deleteStudent(
                                                        student.sid
                                                    )
                                                }
                                            >
                                                Delete
                                            </button>

                                        </td>

                                    </tr>

                                )
                            )}

                        </tbody>

                    </table>

                )}

            </div>

        </div>
    );
}

export default StudentList;