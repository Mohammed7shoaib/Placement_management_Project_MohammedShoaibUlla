import React, { useState, useEffect } from "react";
import API_URL from "../../api";

function StudentForm({
  fetchStudents,
  editingStudent,
  setEditingStudent
}) {
  const [name, setName] = useState("");
  const [phoneno, setPhoneno] = useState("");
  const [collegeName, setCollegeName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (editingStudent) {
      setName(editingStudent.name || "");
      setPhoneno(editingStudent.phoneno || "");
      setCollegeName(editingStudent.collegeName || "");
    } else {
      setName("");
      setPhoneno("");
      setCollegeName("");
    }
  }, [editingStudent]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError("");
    setLoading(true);

    const student = {
      name,
      phoneno,
      collegeName
    };

    try {
      const url = editingStudent
        ? `${API_URL}/updatestudent/${editingStudent.sid}`
        : `${API_URL}/savestudent`;

      const response = await fetch(url, {
        method: editingStudent ? "PUT" : "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(student)
      });

      if (!response.ok) {
        const message = await response.text();
        throw new Error(message || "Failed to save student");
      }

      await fetchStudents();

      setEditingStudent(null);

      setName("");
      setPhoneno("");
      setCollegeName("");

    } catch (error) {
      console.error("Error saving student:", error);

      setError(
        "Could not save student. Please check the backend."
      );
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setEditingStudent(null);
    setName("");
    setPhoneno("");
    setCollegeName("");
    setError("");
  };

  return (
    <div className="card form-card">

      <h3>
        {editingStudent ? "Edit Student" : "Add Student"}
      </h3>

      {error && (
        <div className="error-box">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit}>

        <div className="form-grid">

          <div className="field">
            <label>Student Name</label>

            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>

          <div className="field">
            <label>Phone Number</label>

            <input
              type="text"
              value={phoneno}
              onChange={(e) => setPhoneno(e.target.value)}
              required
            />
          </div>

          <div className="field">
            <label>College Name</label>

            <input
              type="text"
              value={collegeName}
              onChange={(e) => setCollegeName(e.target.value)}
              required
            />
          </div>

        </div>

        <div className="form-actions">

          <button
            className="btn btn-primary"
            type="submit"
            disabled={loading}
          >
            {loading
              ? "Saving..."
              : editingStudent
              ? "Update Student"
              : "Add Student"}
          </button>

          {editingStudent && (
            <button
              className="btn btn-secondary"
              type="button"
              onClick={handleCancel}
            >
              Cancel
            </button>
          )}

        </div>

      </form>

    </div>
  );
}

export default StudentForm;