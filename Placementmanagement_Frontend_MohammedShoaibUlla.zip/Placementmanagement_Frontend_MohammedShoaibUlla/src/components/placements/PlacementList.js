import React, { useEffect, useState } from "react";
import API_URL from "../../api";

function PlacementList() {
  const [placements, setPlacements] = useState([]);
  const [form, setForm] = useState({
    name: "",
    qualification: "",
    year: ""
  });
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState("");

  const fetchPlacements = async () => {
    try {
      const response = await fetch(`${API_URL}/getplacement`);
      if (!response.ok) throw new Error();
      setPlacements(await response.json());
    } catch (err) {
      console.error(err);
      setError("Could not load placements.");
    }
  };

  useEffect(() => {
    fetchPlacements();
  }, []);

  const resetForm = () => {
    setForm({ name: "", qualification: "", year: "" });
    setEditingId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const url = editingId
        ? `${API_URL}/updateplace/${editingId}`
        : `${API_URL}/saveplacement`;

      const response = await fetch(url, {
        method: editingId ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });

      if (!response.ok) throw new Error();

      resetForm();
      fetchPlacements();
    } catch (err) {
      console.error(err);
      setError("Could not save placement.");
    }
  };

  const deletePlacement = async (id) => {
    if (!window.confirm("Are you sure you want to delete this placement?")) return;

    try {
      const response = await fetch(`${API_URL}/deleteplace/${id}`, {
        method: "DELETE"
      });

      if (!response.ok) throw new Error();
      fetchPlacements();
    } catch (err) {
      console.error(err);
      setError("Could not delete placement.");
    }
  };

  return (
    <div>
      <div className="page-header">
        <h2>Placement Management</h2>
        <p>Manage placement records.</p>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="card form-card">
        <form onSubmit={handleSubmit}>
          <div className="form-grid">
            <div className="field">
              <label>Name</label>
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
              />
            </div>

            <div className="field">
              <label>Qualification</label>
              <input
                value={form.qualification}
                onChange={(e) =>
                  setForm({ ...form, qualification: e.target.value })
                }
                required
              />
            </div>

            <div className="field">
              <label>Year</label>
              <input
                type="number"
                value={form.year}
                onChange={(e) => setForm({ ...form, year: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="form-actions">
            <button className="btn btn-primary" type="submit">
              {editingId ? "Update Placement" : "Add Placement"}
            </button>

            {editingId && (
              <button className="btn btn-secondary" type="button" onClick={resetForm}>
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>

      <div className="card table-card">
        {placements.length === 0 ? (
          <div className="empty">No placements found.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Qualification</th>
                <th>Year</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {placements.map((placement) => (
                <tr key={placement.id}>
                  <td>{placement.id}</td>
                  <td>{placement.name}</td>
                  <td>{placement.qualification}</td>
                  <td>{placement.year}</td>
                  <td className="action-cell">
                    <button
                      className="btn btn-edit"
                      onClick={() => {
                        setEditingId(placement.id);
                        setForm({
                          name: placement.name || "",
                          qualification: placement.qualification || "",
                          year: placement.year || ""
                        });
                      }}
                    >
                      Edit
                    </button>

                    <button
                      className="btn btn-delete"
                      onClick={() => deletePlacement(placement.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default PlacementList;