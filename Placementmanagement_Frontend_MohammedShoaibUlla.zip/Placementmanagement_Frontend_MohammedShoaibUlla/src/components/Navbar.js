import React from "react";

const titles = {
  dashboard: "Dashboard",
  students: "Students",
  colleges: "Colleges",
  placements: "Placements",
  certificates: "Certificates",
  users: "Users",
  admins: "Admins"
};

function Navbar({ onMenuClick, activePage }) {
  return (
    <header className="navbar">
      <div className="nav-title">
        <button className="menu-button" onClick={onMenuClick}>
          ☰
        </button>
        <h1>{titles[activePage] || "Placement Management System"}</h1>
      </div>

      <div className="nav-user">
        Placement Management System
      </div>
    </header>
  );
}

export default Navbar;