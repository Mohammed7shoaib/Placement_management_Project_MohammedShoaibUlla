import React, { useState } from "react";
import "./App.css";

import Sidebar from "./components/Sidebar";
import Navbar from "./components/Navbar";
import Dashboard from "./components/Dashboard";

import StudentList from "./components/students/StudentList";
import CollegeList from "./components/colleges/CollegeList";
import PlacementList from "./components/placements/PlacementList";
import CertificateList from "./components/certificates/CertificateList";
import UserList from "./components/users/UserList";
import AdminList from "./components/admins/AdminList";

function App() {
  const [activePage, setActivePage] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const renderPage = () => {
    switch (activePage) {
      case "students":
        return <StudentList />;
      case "colleges":
        return <CollegeList />;
      case "placements":
        return <PlacementList />;
      case "certificates":
        return <CertificateList />;
      case "users":
        return <UserList />;
      case "admins":
        return <AdminList />;
      default:
        return <Dashboard onNavigate={setActivePage} />;
    }
  };

  return (
    <div className="app">
      <Sidebar
        activePage={activePage}
        setActivePage={setActivePage}
        sidebarOpen={sidebarOpen}
      />

      <div className={`main-area ${sidebarOpen ? "" : "expanded"}`}>
        <Navbar
          onMenuClick={() => setSidebarOpen(!sidebarOpen)}
          activePage={activePage}
        />

        <main className="content">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}

export default App;